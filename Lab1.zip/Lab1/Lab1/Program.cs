﻿// Lab 1
// CIS 199-50
// Due: 09/04/2022
// By: F2214

// This projram displays my Grading ID,
// hobbies, favorite book and movie to the console.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Lab1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            WriteLine("Grading ID:      F2214");
            WriteLine("Hobbies:         Playing soccer");
            WriteLine("Favorite Book:   Because of Winn-Dixie");
            WriteLine("Favorite Movie:  Eagle Eye");
        }
    }
}
